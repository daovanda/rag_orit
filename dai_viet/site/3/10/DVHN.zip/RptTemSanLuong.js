var RptTemSanLuong = {
    run: function (p) {

        if (!p.records.length)
            return NUT.notify("⚠️ Bạn chưa chọn bản ghi để in!", "yellow");

        let url = NUT.services[3].url;
        let record = p.records[0];

        NUT.ds.select({
            url: url + "data/TemSL",
            where: [["temsl_id", "=", record.temsl_id]]
        }, function (resTemSL) {

            if (!resTemSL.success || !resTemSL.result.length)
                return NUT.notify("⚠️ Không có dữ liệu nhật ký đùn!", "yellow");

            let tem = resTemSL.result[0];
            let doamins = NUT.domains[1098].items;
            let nhomsp = doamins.find(item => item.id == tem.nhomsp);

            if (nhomsp.id == "eco" || nhomsp.id == "penco") {
                //Mở File tem sản lượng eco+penco
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemSanLuong.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);

                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "manfilm") {
                //Mở File tem sản lượng màng Film
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemSLmangFilm.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "temop") {
                //Mở File tem sản lượng tem ốp đa năng
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/TemSLoptuong.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "ecokin" || nhomsp.id == "ecokhongin") {
                //Mở File tem sản lượng eco+ hàng không in
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemslEcokin.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "icasa composite") {
                //Mở File tem sản lượng icasa composite
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemslIcasa.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "lux" || nhomsp.id == "luxeco") {
                //Mở File tem sản lượng lux, luxeco,..
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemslLux.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "tamop") {
                //Mở File tem sản lượng tấm ốp đa năng
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemslTamOpDaNang.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else if (nhomsp.id == "lamsong") {
                //Mở File tem sản lượng lam sóng
                let win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptaTemslLamSong.html");
                win.onload = function () {
                    let template = win.document.getElementById("template").outerHTML;
                    let html = "";
                    let pageContent = "";

                    for (let i = (tem.sotem_min ?? 1); i <= tem.soluongtem; i++) {
                        let temp = template
                            .replace('id="tieude"></span>', `id="tieude">${nhomsp.text || ""}</span>`)
                            .replace('id="maydun"></td>', `id="maydun">MÁY ĐÙN: ${tem.maydun || ""}</td>`)
                            .replace('id="tomay"></td>', `id="tomay">TỔ MÁY: ${tem.tomay || ""}</td>`)
                            .replace('id="toin"></td>', `id="toin">TỔ IN: ${tem.toin || ""}</td>`)
                            .replace('id="seri"></td>', `id="seri">SERI: ${i}${tem.seri || ""}</td>`)
                            .replace('id="ca"><div', `id="ca">${tem.ca || ""}<div`);
                        pageContent += temp;

                        if (i % 3 === 0) {
                            html += `<div class="page">${pageContent}</div>`;
                            pageContent = "";
                        }
                    }

                    if (pageContent) {
                        html += `<div class="page">${pageContent}</div>`;
                    }

                    win.document.body.innerHTML = html;
                    win.document.close();
                };
            } else {
                return NUT.notify("⚠️ Không phù hợp!", "yellow");
            }

        });
    }
}
