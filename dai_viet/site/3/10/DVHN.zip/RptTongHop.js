var RptTongHop = {
    run: function () {
        let url = NUT.services[3].url;
        var now = (new Date()).toISOString().substring(0, 10);
        var domainNhomsp = NUT.domains[1098];
        var itemsNhomsp = domainNhomsp.items
            .map(i => `<option value="${i.id}">${i.text}</option>`)
            .join('');

        NUT.w2popup.open({
            title: '📃 <i>Báo cáo tổng hợp</i>',
            modal: true,
            width: 320,
            height: 240,
            body: `
                    <table style='margin:auto'>                  
                        <tr>
                            <td>Từ ngày*</td>
                            <td><input id='datTuNgay' type='date' value='${now}'/></td>
                        </tr>
                        <tr>
                            <td>Đến ngày*</td>
                            <td><input id='datDenNgay' type='date' value='${now}'/></td>
                        </tr>
                        <tr>
                            <td>Nhóm sản phẩm *</td>
                            <td colspan='3' id='cboNhomsp'> <select> ${itemsNhomsp} </select></td> 
                        </tr>
                    </table>
            `,
            actions: {
                "_Close": function () {
                    NUT.w2popup.close();
                },
                "_Ok": function () {
                    var cboNhomsp = document.getElementById("cboNhomsp");
                    var datTuNgay = document.getElementById("datTuNgay");
                    var datDenNgay = document.getElementById("datDenNgay");

                    if (cboNhomsp.value && datTuNgay.value && datDenNgay.value) {
                        var whereConditions = [
                            ["ngay", ">=", datTuNgay.value],
                            ["ngay", "<=", datDenNgay.value]
                        ];

                    } else {
                        NUT.notify("⚠️ Chọn ca, từ ngày và đến ngày!", "yellow");
                    }
                }
            }
        });
    }
}