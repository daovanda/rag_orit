var RptDun = {
    run: function (p) {
        p = p || {};
        RptDun.url = NUT.services[3].url;
        var domainObj = NUT.domains[1092] || {};
        var items = domainObj.items || [];

        var cboCa = document.createElement("select");
        cboCa.id = "cboCa";
        cboCa.className = 'w2ui-input';
        cboCa.style.width = "230px";
        var optAll = document.createElement("option");
        optAll.value = "";
        optAll.innerHTML = "Chọn ca";
        cboCa.add(optAll);
        items.filter(item => item.text && item.text.trim() !== "").sort((a, b) => a.id - b.id).forEach(function (item) {
            var opt = document.createElement("option");
            opt.value = item.text || "";
            opt.innerHTML = item.text || "";
            cboCa.add(opt);
        });

        var now = (new Date()).toISOString().substring(0, 10);
        if (p.records && p.records.length) {
            var selectedRecord = p.records[0];

            NUT.ds.select({
                url: RptDun.url + "data/nkdun",
                where: [["nkdunid", "=", selectedRecord.nkdunid]]
            }, function (resNK) {
                if (!resNK.success || !resNK.result.length) {
                    return NUT.notify("⚠️ Không có dữ liệu nhật ký đùn cho bản ghi đã chọn!", "yellow");
                }
                var nk = resNK.result[0];

                NUT.ds.select({
                    url: RptDun.url + "data/ctnkdun_v",
                    where: [["nkdunid", "=", nk.nkdunid]]
                }, function (resCT) {
                    if (!resCT.success) {
                        return NUT.notify("⚠️ Không lấy được dữ liệu chi tiết!", "yellow");
                    }

                    var win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptDun.html");
                    win.onload = function () {
                        var table = win.document.getElementById("tblData");
                        if (!table) return;

                        var firstRow = table.rows[0];
                        firstRow.cells[0].innerHTML = `NGÀY: ${nk.ngay ? new Date(nk.ngay).toLocaleDateString('vi-VN') : ""}`;
                        firstRow.cells[1].innerHTML = `CA SẢN XUẤT: ${nk.ca || ""}`;
                        firstRow.cells[2].innerHTML = `TÊN TỔ TRƯỞNG: ${nk.totruong || ""}`;

                        let stt = 1;
                        resCT.result.forEach(function (ct) {
                            var row = win.document.createElement("tr");
                            row.innerHTML = `
                                <td>${stt++}</td>
                                <td>${ct.somaydun || ""}</td>
                                <td>${ct.soxedun || ""}</td>
                                <td>${ct.sotem || ""}</td>
                                <td>${ct.quycach || ""}</td>
                                <td>${ct.mamau || ""}</td>
                                <td>${ct.sltam || ""}</td>
                                <td>${ct.kltong || ""}</td>
                                <td>${ct.klxe || ""}</td>
                                <td>${ct.klhang || ""}</td>
                                <td>${ct.kldinhmuc || ""}</td>
                                <td>${ct.klchenhlech || ""}</td>
                                <td>${ct.klphe || ""}</td>
                                <td>${ct.ghichuct || ""}</td>
                            `;
                            table.appendChild(row);
                        });
                    };
                });
            });
        }

        else if (p.popup || (!p.records && typeof p.records === 'undefined')) {
            NUT.w2popup.open({
                title: '📃 <i>Báo cáo đùn</i>',
                modal: true,
                width: 300,
                height: 250,
                body: `
                    <table style='margin:auto'>                  
                        <tr>
                            <td>Từ ngày*</td>
                            <td><input id='datTuNgay' type='date' value='${now}'/></td>
                        </tr>
                        <tr>
                            <td>Đến ngày*</td>
                            <td><input id='datDenNgay' type='date' value='${now}'/></td>
                        </tr>
                        <tr>
                            <td>Ca *</td>
                            <td colspan='3'>` + cboCa.outerHTML + `</td>
                        </tr>
                    </table>
                `,
                actions: {
                    "_Close": function () {
                        NUT.w2popup.close();
                    },
                    "_Ok": function () {
                        var cboCa = document.getElementById("cboCa");
                        var datTuNgay = document.getElementById("datTuNgay");
                        var datDenNgay = document.getElementById("datDenNgay");

                        if (cboCa.value && datTuNgay.value && datDenNgay.value) {
                            var whereConditions = [
                                ["ngay", ">=", datTuNgay.value],
                                ["ngay", "<=", datDenNgay.value]
                            ];
                            if (cboCa.value !== "") {
                                whereConditions.push(["ca", "=", cboCa.value]);
                            }

                            NUT.ds.select({
                                url: RptDun.url + "data/nkdun",
                                where: whereConditions,
                                orderby: "ngay, ca"
                            }, function (resNK) {
                                if (!resNK.success || !resNK.result.length) {
                                    return NUT.notify("⚠️ Không có dữ liệu nhật ký đùn!", "yellow");
                                }

                                var ids = resNK.result.map(r => r.nkdunid);
                                NUT.ds.select({
                                    url: RptDun.url + "data/ctnkdun_v",
                                    where: [["nkdunid", "in", ids]]
                                }, function (resCT) {
                                    if (!resCT.success) {
                                        return NUT.notify("⚠️ Không lấy được dữ liệu chi tiết!", "yellow");
                                    }

                                    var detailsByNK = {};
                                    resCT.result.forEach(function (ct) {
                                        if (!detailsByNK[ct.nkdunid]) {
                                            detailsByNK[ct.nkdunid] = [];
                                        }
                                        detailsByNK[ct.nkdunid].push(ct);
                                    });

                                    var win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptDun.html");
                                    win.onload = function () {
                                        var templateTable = win.document.getElementById("tblData");
                                        if (!templateTable) return;

                                        resNK.result.forEach(function (nk, index) {
                                            var table = templateTable.cloneNode(true);
                                            table.removeAttribute("id");

                                            var firstRow = table.rows[0];
                                            firstRow.cells[0].innerHTML = `NGÀY: ${nk.ngay ? new Date(nk.ngay).toLocaleDateString('vi-VN') : ""}`;
                                            firstRow.cells[1].innerHTML = `CA SẢN XUẤT: ${nk.ca || ""}`;
                                            firstRow.cells[2].innerHTML = `TÊN TỔ TRƯỞNG: ${nk.totruong || ""}`;

                                            var rows = detailsByNK[nk.nkdunid] || [];
                                            let stt = 1;
                                            rows.forEach(function (ct) {
                                                var row = win.document.createElement("tr");
                                                row.innerHTML = `
                                                    <td>${stt++}</td>
                                                    <td>${ct.somaydun || ""}</td>
                                                    <td>${ct.soxedun || ""}</td>
                                                    <td>${ct.sotem || ""}</td>
                                                    <td>${ct.quycach || ""}</td>
                                                    <td>${ct.mamau || ""}</td>
                                                    <td>${ct.sltam || ""}</td>
                                                    <td>${ct.kltong || ""}</td>
                                                    <td>${ct.klxe || ""}</td>
                                                    <td>${ct.klhang || ""}</td>
                                                    <td>${ct.kldinhmuc || ""}</td>
                                                    <td>${ct.klchenhlech || ""}</td>
                                                    <td>${ct.klphe || ""}</td>
                                                    <td>${ct.ghichuct || ""}</td>
                                                `;
                                                table.appendChild(row);
                                            });

                                            win.document.body.appendChild(table);
                                            if (index < resNK.result.length - 1) {
                                                let pageBreak = win.document.createElement("div");
                                                pageBreak.style.pageBreakAfter = "always";
                                                win.document.body.appendChild(pageBreak);
                                            }
                                        });

                                        templateTable.remove();
                                    };

                                });
                            });
                        } else {
                            NUT.notify("⚠️ Chọn ca, từ ngày và đến ngày!", "yellow");
                        }
                    }
                }
            });
        }

        else {
            NUT.notify("không có bản ghi nào được chọn!", "yellow");
        }
    }
};
