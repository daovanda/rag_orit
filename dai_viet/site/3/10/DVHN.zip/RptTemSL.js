var RptTemSL = {
    run: function (p) {
        if (!p.records.length)
            return NUT.notify("⚠️ No record selected!", "yellow");

        let ct = p.records[0];
        let nkdunid = ct.nkdunid;
        let url = NUT.services[3].url;

        NUT.ds.select({
            url: url + "data/nkdun",
            where: [["nkdunid", "=", nkdunid]]
        }, function (resNK) {
            if (!resNK.success || !resNK.result.length)
                return NUT.notify("⚠️ Không có dữ liệu nhật ký đùn!", "yellow");

            let nk = resNK.result[0];

            var win = window.open("site/" + n$.user.siteid + "/" + n$.app.appid + "/RptTemSL.html");
            win.onload = function () {
                win.document.getElementById("maydun").innerHTML = `MÁY ĐÙN: ${nk.maydun || ""}`;
                win.document.getElementById("tomay").innerHTML = `TỔ MÁY: ${nk.tomay || ""}`;
                win.document.getElementById("toin").innerHTML = `TỔ IN: ${nk.toin || ""}`;
                win.document.getElementById("seri").innerHTML = `SERI: ${ct.sotem || ""}`;

                var table = win.document.getElementById("tblData");
                var row = win.document.createElement("tr");
                row.innerHTML = `
                    <td>${nk.ca || ""}</td>
                    <td>${ct.quycach || ""}</td>
                    <td>${ct.sldun || ""}</td>
                    <td>${ct.sltam || ""}</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                `;
                table.appendChild(row);
            };
        });
    }
}
