var GenerateRecord = {
    run: function (p) {
        var parent = p.parent;
        let url = NUT.services[3].url;
        let total = parent.soluongtem - parent.sotem_min + 1;
        let done = 0;

        for (let i = parent.sotem_min; i <= parent.soluongtem; i++) {
            const data = {
                id: `${i}${parent.seri}`,
                temsl_id: parent.temsl_id,
				nhomsp: parent.nhomsp
            };

            NUT.ds.insert({
                url: url + "data/ctTemSL",
                data: data
            }, function (res) {
                done++;

                if (!res.success) {
                    console.warn("Insert lỗi:", data.id);
                }

                if (done === total) {
                    let grid = NUT.w2ui["grid_" + p.config.tabid];
                    grid.reload();
                    NUT.notify("Generate xong!", "green");
                }
            });
        }
    }
};
